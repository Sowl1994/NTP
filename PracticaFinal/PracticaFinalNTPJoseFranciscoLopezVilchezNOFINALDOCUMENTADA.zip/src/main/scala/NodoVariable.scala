class NodoVariable(variable:Variable) extends Nodo {
  //Variables de la clase NodoVariable
  val nivel = variable
  val hijos = variable.estados
  var listaAsignaciones = List[Asignacion]()
  var listaNodos = List[Nodo]()

  /**
    * Método que permite ir almacenando las asignaciones con las que se llega a el nodo en cuestión
    * @param asignacion asignación a almacenar
    */
  def aniadirHijo(asignacion: Asignacion):Unit=listaAsignaciones = listaAsignaciones:+asignacion

  /**
    * Método que permite el almacenamiento de los nodos hijos
    * @param nodo nodo a almacenar
    */
  def aniadeNodo(nodo: Nodo):Unit=listaNodos = listaNodos:+nodo

  /**
    * Obtenemos el hijo del nodo
    * @param indice indice del nodo, el cual poseerá un hijo a devolver
    * @return
    */
  override def obtenerHijo(indice: Int): Nodo = this.listaNodos(indice)

  override def obtenerValor(asignacion: Asignacion): Int = {
    println(this.listaAsignaciones)
    println(listaNodos)

    ???
  }

  override def obtenerValores: List[Int] = {
    ???
  }
}
object NodoVariable{

  /**
    * Método que permite la creación de objetos de la clase NodoVariable de forma sencilla
    * @param variable variable del NodoVariable
    * @return
    */
  def apply(variable: Variable): NodoVariable = new NodoVariable(variable)
}
