abstract class Nodo {
  val nivel:Variable

  override def toString: String = {
    nivel.toString
  }
  def obtenerHijo(indice:Int):Any
  def obtenerValores:List[Int]
  def obtenerValor(asignacion: Asignacion): Int

}