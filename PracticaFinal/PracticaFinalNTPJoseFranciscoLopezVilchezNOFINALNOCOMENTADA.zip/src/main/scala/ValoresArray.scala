class ValoresArray(dom:Dominio,lista:List[Int]) extends Valores{
  val dominio = dom
  var listaDeValores = lista
  /**
    * Método que sobreescribe toString. En este caso particular, recorre todas las asignaciones posibles
    * y les da el valor a cada una
    * guardándolas en la cadena final a mostrar
    * @return
    */
  override def toString: String ={
    var cadena = super.toString + "Array: \n"/*+dom.variables+lista+"\n"*/
    var asignacionPosible = List.fill(dom.indiceVariables.size)(0)
    var ultimo = dom.indiceVariables.size-1
    //Creamos una lista para comparar a ver si tenemos ya todas las asignaciones recorridas
    //(Vemos si es la ultima)
    var listaCasoBase = List[Int]()
    dom.indiceVariables.foreach((f:Int)=>{
      listaCasoBase = listaCasoBase :+ f-1
    })

    @annotation.tailrec
    def todasAsignaciones(indice:List[Int],ultimoD:Int): Any ={
      //println(indice + " " +ultimo)
      var ultimoAux = ultimoD
      var recargarLista = indice
      //Si la asignacion pasada por parámetro es la última a analizar, la imprimimos y acabamos
      if (indice.equals(listaCasoBase)){
        val asignacion = Asignacion.apply(dom, indice)
        val valor = obtenerValor(asignacion)
        cadena+=asignacion+" = "+valor+"\n"
      }else{
        //println("Posicion: "+ ultimoD +"\n" +indice(ultimoD) + " vs " + (dom.indiceVariables(ultimoD)-1))
        if(indice(ultimoD) < (dom.indiceVariables(ultimoD)-1)){
          //println("el ultimoD es inferior a su limite -> "+indice)
          val asignacion = Asignacion.apply(dom, indice)
          val valor = obtenerValor(asignacion)
          cadena+=asignacion+" = "+valor+"\n"
          recargarLista = indice.updated(ultimoD,indice(ultimoD)+1)
        }else{
          //println("1 -> "+indice)
          if(indice(ultimo) > 0){
            val asignacion = Asignacion.apply(dom, indice)
            val valor = obtenerValor(asignacion)
            cadena+=asignacion+" = "+valor+"\n"
          }

          recargarLista = indice.updated(ultimoD,0)
          if(indice(ultimoD-1) < (dom.indiceVariables(ultimoD-1)-1)){
            recargarLista = recargarLista.updated(ultimoD-1,indice(ultimoD-1)+1)
            //println("2 -> "+indice)
            ultimoAux = ultimo
          }else{
            //println("3 -> "+indice)
            ultimoAux = ultimoD-1
          }
        }
        todasAsignaciones(recargarLista,ultimoAux)
      }
    }
    todasAsignaciones(asignacionPosible,ultimo)

    cadena
  }

  /**
    * Obtencion del valor correspondiente a una asignacion pasada por parámetro
    * @param asignacion
    * @return
    */
  override def obtenerValor(asignacion: Asignacion): Int = {
    @annotation.tailrec
    def go(listaV:List[Int], indiceD:Int, dominio: Dominio): List[Int] ={
      //Si llegamos al ultimo valor del dominio, devolvemos la lista de valores posibles
      if(indiceD  == dom.variables.size-1){
        listaV
      }else{
        //Obtenemos el indice y los estados de la variable
        val variableDominio = dom.apply(indiceD)
        val indiceVariable = asignacion.obtenerValorVariable(dom.apply(indiceD))
        val estadosVariable = dom.apply(indiceD).estados
        val nAgrupacion = dominio.maximoIndice+1
        //Agrupamos la lista por el numero de elementos que nos sale de dividir
        //el maximo indice del dominio entre los estados de la variable analizada
        //Tras esto, escogemos la lista designada por el indice de la variable(el que sacamos de la asignacion)
        val listaOK = listaV.grouped((nAgrupacion/estadosVariable)).toList(indiceVariable)
        //Pasamos la lista para volverla a analizar, junto con un incremento del indice para comprobar la siguiente variable
        // de la asignacion dada al principio
        go(listaOK,indiceD+1,dominio-variableDominio)
      }
    }
    //Obtenemos la lista de valores posibles a falta de escoger el ultimo de la asignacion
    val valor = go(lista,0,asignacion.dominio)
    //Este indiceFinal nos dirá que valor cogeremos
    val indiceFinal = asignacion.obtenerValorVariable(asignacion.dominio.apply(asignacion.dominio.variables.size-1))
    //Devolvemos el valor
    valor(indiceFinal)
  }
  override def obtenerVariables:List[Variable]= dom.variables
  override def obtenerValores: List[Int] = lista

  /**
    *
    * @param x
    * @return
    */
  def combinarArrayArray(x:Valores):ValoresArray ={
    //Comprobamos el elemento a combinar, si es un valoresArbol, lo convertimos a valoresArray; si no, continuamos
    var vArray:ValoresArray = x.asInstanceOf[ValoresArray]
    def compruebaTipo[T](v: T) = v match {
      case _: ValoresArray =>{
        vArray = x.asInstanceOf[ValoresArray]
      }
      case _: ValoresArbol => {
        vArray = convertir(x).asInstanceOf[ValoresArray]
      }
    }
    compruebaTipo(x)

    val dominioFinal = dominio + vArray.dominio
    var listaValores = List[Int]()
    println(dominioFinal)

    var asignacionPosible = List.fill(dominioFinal.indiceVariables.size)(0)
    var ultimo = dominioFinal.indiceVariables.size-1
    var listaCasoBase = List[Int]()
    dominioFinal.indiceVariables.foreach((f:Int)=>{
      listaCasoBase = listaCasoBase :+ f-1
    })

    @annotation.tailrec
    def go(indice:List[Int],ultimoD:Int): Any ={
      var ultimoAux = ultimoD
      var recargarLista = indice
      if (indice.equals(listaCasoBase)){

        val asignacionFinal = Asignacion(dominioFinal, indice)
        //println("asignacionFinal -> "+ asignacionFinal)
        val asignacionThis = Asignacion.proyectar(asignacionFinal,dominio)
        //println("asignacionThis -> "+ asignacionThis)
        val asignacionOtro = Asignacion.proyectar(asignacionFinal,vArray.dominio)
        //println("asignacionOtro -> "+ asignacionOtro)
        val producto = obtenerValor(asignacionThis)*vArray.obtenerValor(asignacionOtro)
        //println("producto ->"+producto)

        listaValores = listaValores :+ producto

      }else{
        if(indice(ultimoD) < (dominioFinal.indiceVariables(ultimoD)-1)){

          val asignacionFinal = Asignacion(dominioFinal, indice)
          val asignacionThis = Asignacion.proyectar(asignacionFinal,dominio)
          val asignacionOtro = Asignacion.proyectar(asignacionFinal,vArray.dominio)
          val producto = obtenerValor(asignacionThis)*vArray.obtenerValor(asignacionOtro)

          listaValores = listaValores :+ producto
          recargarLista = indice.updated(ultimoD,indice(ultimoD)+1)
        }else{
          //println("indiceD 2 -> " + indice)
          if(indice(ultimo) > 0) {
            val asignacionFinal = Asignacion(dominioFinal, indice)
            val asignacionThis = Asignacion.proyectar(asignacionFinal, dominio)
            val asignacionOtro = Asignacion.proyectar(asignacionFinal, vArray.dominio)
            val producto = obtenerValor(asignacionThis) * vArray.obtenerValor(asignacionOtro)

            listaValores = listaValores :+ producto
          }

          recargarLista = indice.updated(ultimoD,0)
          if(indice(ultimoD-1) < (dom.indiceVariables(ultimoD-1)-1)){
            recargarLista = recargarLista.updated(ultimoD-1,indice(ultimoD-1)+1)
            ultimoAux = ultimo
          }else{
            ultimoAux = ultimoD-1
          }
        }

        go(recargarLista, ultimoAux)
      }
    }

    go(asignacionPosible,ultimo)

    ValoresArray(dominioFinal,listaValores)
  }

  /**
    *
    * @param variable
    * @param estado
    * @return
    */
  override def restringir(variable: Variable,estado: Int): ValoresArray = {
    val dominioFinal = dom-variable
    var valoresR = List[Int]()
    //println("Estado: " + estado)

    //println("dominioFinal "+dominioFinal.indiceVariables)

    var asignacionPosible = List.fill(dominioFinal.indiceVariables.size)(0)
    var ultimo = dominioFinal.indiceVariables.size-1
    var listaCasoBase = List[Int]()
    dominioFinal.indiceVariables.foreach((f:Int)=>{
      listaCasoBase = listaCasoBase :+ f-1
    })

    @annotation.tailrec
    def go(indice:List[Int],ultimoD:Int): Any ={
      var ultimoAux = ultimoD
      var recargarLista = indice
      if (indice.equals(listaCasoBase)){
        //println("Final-> " + indice)
        val asignacionFinal = Asignacion.apply(dominioFinal,indice)
        //println("asignacionFinal -> "+asignacionFinal)
        val asignacionCompleta = asignacionFinal + (variable, estado)
        //println("asignacionCompleta -> "+asignacionCompleta)
        val asignacionOrdenada = Asignacion.proyectar(asignacionCompleta,dom)
        //println("asignacionOrdenada -> "+asignacionOrdenada)
        val valor = obtenerValor(asignacionOrdenada)
        //println("valor -> "+valor)
        valoresR = valoresR :+ valor
        //println("valoresR -> "+valoresR)
      }else{
        //println("Comparacion -> " + indice(ultimoD) + " vs " + (dominioFinal.indiceVariables(ultimoD)-1) )
        if(indice(ultimoD) < (dominioFinal.indiceVariables(ultimoD)-1)){
          //println("indiceD 1 -> " + indice)
          val asignacionFinal = Asignacion.apply(dominioFinal,indice)
          //println("asignacionFinal -> "+asignacionFinal)
          val asignacionCompleta = asignacionFinal + (variable, estado)
          //println("asignacionCompleta -> "+asignacionCompleta)
          val asignacionOrdenada = Asignacion.proyectar(asignacionCompleta,dom)
          //println("asignacionOrdenada -> "+asignacionOrdenada)
          val valor = obtenerValor(asignacionOrdenada)
          //println("valor -> "+valor)
          valoresR = valoresR :+ valor
          //println("valoresR -> "+valoresR)

          recargarLista = indice.updated(ultimoD,indice(ultimoD)+1)
          println(recargarLista)

        }else{
          //println("indice ultimod +1 ->"+ultimoD+" "+indice(ultimoD)+" "+recargarLista)
          val asignacionFinal = Asignacion.apply(dominioFinal,indice)
          //println("asignacionFinal -> "+asignacionFinal)
          val asignacionCompleta = asignacionFinal + (variable, estado)
          //println("asignacionCompleta -> "+asignacionCompleta)
          val asignacionOrdenada = Asignacion.proyectar(asignacionCompleta,dom)
          //println("asignacionOrdenada -> "+asignacionOrdenada)
          val valor = obtenerValor(asignacionOrdenada)
          //println("valor -> "+valor)
          valoresR = valoresR :+ valor
          //println("valoresR -> "+valoresR)

          recargarLista = indice.updated(ultimoD,0)
          //println("indice ultimod -1 ->"+ultimoD+" "+indice(ultimoD)+" "+recargarLista)
          if (ultimoD == 0){
            recargarLista = listaCasoBase
          }else{
            if(indice(ultimoD-1) < (dom.indiceVariables(ultimoD-1)-1)){
              recargarLista = recargarLista.updated(ultimoD-1,indice(ultimoD-1)+1)
              ultimoAux = ultimo
            }else{
              ultimoAux = ultimoD-1
            }
          }
          println(recargarLista)

        }

        go(recargarLista, ultimoAux)
      }
    }

    go(asignacionPosible,ultimo)

    ValoresArray.apply(dominioFinal,valoresR)
  }

  /**
    *
    * @param x
    * @return
    */
  def convertirAArbol(x:Valores): Valores=ValoresArbol(dominio,lista)

}

object ValoresArray{
  /**
    * Metodo que permite crear objetos de la clase ValoresArray con un Dominio y una lista de valores
    * @param dominio
    * @param lista
    * @return
    */
  def apply(dominio: Dominio,lista: List[Int]): ValoresArray = new ValoresArray(dominio,lista)
}
