class PotencialArbol(dominio: Dominio, valoresArbol: ValoresArbol) extends Potencial(dominio,valoresArbol) {

}
object PotencialArbol{
  def apply(dominio: Dominio, valoresArbol: ValoresArbol): PotencialArbol = new PotencialArbol(dominio, valoresArbol)
}
