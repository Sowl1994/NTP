class ValoresArbol(dominio: Dominio, nodo: Nodo) extends Valores {
  val raiz = nodo

  override def toString: String =  {
    var cadena = super.toString +"Arbol"


    cadena
  }

  override def obtenerValor(asignacion: Asignacion): Int = {

    @annotation.tailrec
    def go(indice:Int, nodoValor:Nodo):Int={
      if (indice == asignacion.dominio.variables.size-1){
        val valorAsignacion = asignacion.listaValores(indice)
        nodoValor.asInstanceOf[NodoVariable].listaNodos(valorAsignacion).asInstanceOf[NodoHoja].valorFinal
      }else{
        val valorAsignacion = asignacion.listaValores(indice)
        val nodoH = nodoValor.asInstanceOf[NodoVariable].listaNodos(valorAsignacion)
        go(indice+1,nodoH)
      }
    }

    val valor = go(0,nodo)
    valor
  }

  override def obtenerVariables: List[Variable] = dominio.variables

  /**
    * Obtenemos todos los valores del arbol recorriendo todas sus posibles asignaciones
    * @return
    */
  override def obtenerValores: List[Int] = {
    var listaFinal = List[Int]()
    var asignacionPosible = List.fill(dominio.indiceVariables.size)(0)
    var ultimo = dominio.indiceVariables.size-1
    var listaCasoBase = List[Int]()
    dominio.indiceVariables.foreach((f:Int)=>{
      listaCasoBase = listaCasoBase :+ f-1
    })

    @annotation.tailrec
    def go(indice:List[Int],ultimoD:Int): Unit ={
      var ultimoAux = ultimoD
      var recargarLista = indice
      if (indice.equals(listaCasoBase)){
        listaFinal = listaFinal :+ obtenerValor(Asignacion(dominio,indice))

      }else{
        if(indice(ultimoD) < (dominio.indiceVariables(ultimoD)-1)){
          //println(Asignacion(dominio,indice) +" = " + obtenerValor(Asignacion(dominio,indice)))
          listaFinal = listaFinal :+ obtenerValor(Asignacion(dominio,indice))

          recargarLista = indice.updated(ultimoD,indice(ultimoD)+1)
        }else{
          if(indice(ultimo) > 0) {
            //println(Asignacion(dominio,indice) +" = " + obtenerValor(Asignacion(dominio,indice)))
            listaFinal = listaFinal :+ obtenerValor(Asignacion(dominio,indice))
          }
          recargarLista = indice.updated(ultimoD,0)
          if(indice(ultimoD-1) < (dominio.indiceVariables(ultimoD-1)-1)){
            recargarLista = recargarLista.updated(ultimoD-1,indice(ultimoD-1)+1)
            ultimoAux = ultimo
          }else{
            ultimoAux = ultimoD-1
          }
        }

        go(recargarLista, ultimoAux)
      }
    }

    go(asignacionPosible,ultimo)

    listaFinal
  }
  def combinarArbolArbol(x:Valores): ValoresArbol ={
    //Comprobamos el elemento a combinar, si es un valoresArray, lo convertimos a valoresArbol; si no, continuamos
    var vArbol:ValoresArbol = x.asInstanceOf[ValoresArbol]
    def compruebaTipo[T](v: T) = v match {
      case _: ValoresArbol =>{
        vArbol = x.asInstanceOf[ValoresArbol]
      }
      case _: ValoresArray => {
        vArbol = convertir(x).asInstanceOf[ValoresArbol]
      }
    }
    compruebaTipo(x)

    vArbol
  }
  def obtenerHijo(hijo:Int):Nodo={
    //Si es un nodoVariable, devolvemos el nodo deseado
    if(nodo.isInstanceOf[NodoVariable]){
      val nodoHijo = nodo.asInstanceOf[NodoVariable].listaNodos(hijo)
      //println(nodoHijo.asInstanceOf[NodoVariable].listaNodos(1).asInstanceOf[NodoVariable].listaNodos(1).asInstanceOf[NodoHoja].valorFinal)
      nodoHijo
    }else{
      val nodoHijo = nodo.asInstanceOf[NodoVariable].listaNodos(hijo)
      nodoHijo
    }
  }
  override def restringir(variable: Variable, int: Int): Valores = ???
  def convertirAArray(x:Valores): Valores=ValoresArray(dominio,obtenerValores)
}

object ValoresArbol{
  /**
    * @todo quitar el for
    * @param dominio
    * @param lista
    * @return
    */
  def apply(dominio: Dominio, lista: List[Int]): ValoresArbol = {

    //println(dominio.variables.size)

    def go(indice:Int,asignacion: Asignacion): Nodo ={
      val variableCorrespondiente = dominio.variables(indice)
      val nodo = NodoVariable(variableCorrespondiente)
      //println("go("+indice+", "+asignacion+")")
      //println()
      if (indice >= dominio.variables.size-1) {
        @annotation.tailrec
        def recorreHijos(ini: Int, fin: Int):Unit = {
          if (ini < fin) {
            val asignacionHoja = asignacion + (variableCorrespondiente,ini)
            val hoja = NodoHoja(variableCorrespondiente,lista(asignacionHoja.calcularIndice))
            nodo.aniadeNodo(hoja)
            recorreHijos(ini+1, fin)
          }
        }
        recorreHijos(0,nodo.hijos)
        /*for(i<-0 until nodo.hijos){
          val asignacionHoja = asignacion + (variableCorrespondiente,i)
          val hoja = NodoHoja(variableCorrespondiente,lista(asignacionHoja.calcularIndice))
          println(asignacionHoja+" = "+hoja.valorFinal)
        }*/
      }else{

        @annotation.tailrec
        def recorreHijos(ini: Int, fin: Int):Unit = {
          if (ini < fin) {
            val asignacionSumada = asignacion+(variableCorrespondiente,ini)
            //println(asignacionSumada)
            nodo.aniadirHijo(asignacionSumada)
            val nuevoNodo = go(indice+1,asignacionSumada)
            nodo.aniadeNodo(nuevoNodo)
            recorreHijos(ini+1, fin)
          }
        }
        recorreHijos(0,nodo.hijos)
        /*for(i<-0 until nodo.hijos){
          val asignacionSumada = asignacion + (variableCorrespondiente,i)
          go(indice+1,asignacionSumada)
        }*/
      }

      nodo
    }
    val nodoRaiz = go(0,Asignacion(Dominio(List())))
    //println(nodoRaiz.nivel)

    new ValoresArbol(dominio,nodoRaiz)
  }
}
