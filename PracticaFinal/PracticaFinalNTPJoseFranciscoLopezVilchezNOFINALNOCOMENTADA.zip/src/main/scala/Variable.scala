class Variable(val nombre:String, val nEstados:Int) {
  val nombreV = nombre
  val estados = nEstados

  /**
    * Sobrecarga del método toString para mostrar la variable
    *
    * @return String
    */
  override def toString: String = {
    val elementos = for (i <- 0 to nEstados-1) yield i
    nombre+": "+elementos.mkString("(", ",", ")")
  }
}

object Variable{
  /**
    * Metodo que permite crear objetos de la clase Variable
    * de forma sencilla
    * @param nombre
    * @param nEstados
    * @return
    */
  def apply(nombre:String, nEstados:Int): Variable = new Variable(nombre,nEstados)
}
