class NodoVariable(variable:Variable) extends Nodo {
  val nivel = variable
  val hijos = variable.estados
  var listaAsignaciones = List[Asignacion]()
  var listaNodos = List[Nodo]()

  def aniadirHijo(asignacion: Asignacion):Unit={
    listaAsignaciones = listaAsignaciones:+asignacion
    //println(listaHijos)
  }

  def aniadeNodo(nodo: Nodo):Unit={
    listaNodos = listaNodos:+nodo
    //println(listaNodos)
  }
  override def obtenerHijo(indice: Int): Nodo = this.listaNodos(indice)
  override def obtenerValor(asignacion: Asignacion): Int = {
    println(this.listaAsignaciones)
    println(listaNodos)

    ???
  }

  override def obtenerValores: List[Int] = {
    List(1)
  }
}
object NodoVariable{
  def apply(variable: Variable): NodoVariable = new NodoVariable(variable)
}
