trait Valores {
  override def toString: String = "Valores "
  def obtenerValor(asignacion: Asignacion):Int
  def obtenerVariables:List[Variable]
  def obtenerValores:List[Int]
  def combinar(x:Valores): Valores ={
    def compruebaTipo[T](v: T) = v match {
      case _: ValoresArray    => {
        val v = this.asInstanceOf[ValoresArray].combinarArrayArray(x)
        v
      }
      case _: ValoresArbol => {
        val v = this.asInstanceOf[ValoresArbol].combinarArbolArbol(x)
        v
      }
      /*case _         => {
        println("Recibido un objeto incompatible")
        ???
      }*/
    }

    compruebaTipo(this)
  }
  def restringir(variable: Variable,int: Int):Valores
  def convertir(x:Valores): Valores ={
    def compruebaTipo[T](v: T) = v match {
      case _: ValoresArray    => {
        //println("Recibido un array, convirtiendo en arbol")
        val v = x.asInstanceOf[ValoresArray].convertirAArbol(x)
        v
      }
      case _: ValoresArbol => {
        //println("Recibido un arbol, convirtiendo en array")
        val v = x.asInstanceOf[ValoresArbol].convertirAArray(x)
        v
      }
      /*case _         => {
        println("Recibido un objeto incompatible")
      }*/
    }

    compruebaTipo(x)
  }
}
