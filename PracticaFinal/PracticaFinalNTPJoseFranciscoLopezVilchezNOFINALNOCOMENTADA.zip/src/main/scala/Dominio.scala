class Dominio(lista: List[Variable]) {
  val variables = lista
  var indiceVariables = List[Int]()
  var pesosVariables = List[Int]()

  if (!vacio){
    //inicializacion
    //def inicializacion(): Unit ={
    lista.foreach((e: (Variable)) => indiceVariables = indiceVariables:+e.estados)
    //for(x<- lista.size-1 to 0 by -1)  indiceVariables = lista(x).estados::indiceVariables
    pesosVariables = pesos
    //println(indiceVariables + " " + pesosVariables)
    //}
  }



  /**
    * Sobrecarga del método toString para mostrar el dominio
    *
    * @return String
    */
  override def toString: String = {
    //var cadena = ""
    @annotation.tailrec
    def go(cadena:String, indice:Int):String={
      if (indice == longitud)  cadena
      else{
        var cadAux = cadena
        cadAux += lista(indice).nombre + "(s: "+indiceVariables(indice) +  ", w: "+ pesosVariables(indice) +") "
        go(cadAux, indice+1)
      }
    }
    go("",0)
    //Metodo iterativo
    //for(x<- 0 until lista.size)   cadena += lista(x) /*+ "(s: "+indiceVariables(x) +  ", w: "+ pesosVariables(x)*/ +" "
    //cadena
  }

  /**
    * Sobrecarga del operador + para añadir variables
    * @param variable
    * @return
    */
  def +(variable: Variable):Dominio ={
    //Si la variable ya se encuentra en el dominio, no la introducimos, devolviendo el mismo dominio
    if (!variables.contains(variable)){
      val newList = lista:+variable
      new Dominio(newList)
    }else new Dominio(lista)
  }

  /**
    * Sobrecarga del operador + para añadir dominios
    * @param dominio
    * @return
    */
  def + (dominio: Dominio) ={
    var newList = variables
    dominio.variables.foreach((e:Variable) => {
      if(!variables.contains(e)){
        newList = newList :+ e
      }
    })
    //val listaFinal = lista:::dominio.variables
    //println(listaFinal)
    new Dominio(newList)
  }

  /**
    * Sobrecarga del operador - para eliminar variables
    * @param variable
    * @return
    */
  def -(variable: Variable)={
    if (variables.contains(variable)){
      val listaFinal = variables diff List(variable)
      new Dominio(listaFinal)
    }else{
      //println("No existe dicha variable en el dominio")
      new Dominio(variables)
    }
  }

  /**
    * Devuelve la longitud del dominio
    * @return
    */
  def longitud():Int = lista.size

  /**
    * Comprueba si el dominio está vacío
    * @return
    */
  def vacio:Boolean = if(longitud == 0) true else false

  /**
    * Método que nos da la variable que ocupa la posicion 'posicion' del dominio
    * @param posicion
    * @return
    */
  def apply(posicion: Int): Variable = lista(posicion)

  /**
    * Devuelve la lista de pesos de un dominio
    * @return
    */
  def pesos():List[Int]={
    var listaPesos = List[Int]()  //var aux = 0

    @annotation.tailrec
    def go(longActual:Int, aux:Int):List[Int]={
      //Si es el primer valor, automaticamente guardamos un 1 y continuamos recorriendo el dominio
      if(longActual == longitud-1){
        listaPesos = 1::listaPesos    //aux = 1
        go(longActual-1,1)
      }else{
        val calculaPeso = aux * variables(longActual+1).estados
        listaPesos = calculaPeso :: listaPesos
        //Si es el ultimo valor, realizamos la operación y devolvemos la lista
        if (longActual == 0)
          listaPesos
        //Si no es ni el primer ni el ultimo valor, realizamos la operacion y realizamos llamada recursiva para continuar recorriendo el dominio
        else
          go(longActual-1,calculaPeso)
      }
    }

    //Si el dominio tiene solo longitud 1, peso=1
    if(longitud == 1){
      listaPesos = 1::listaPesos
      listaPesos
    }else go(longitud-1,0)

    //Metodo iterativo -> Recorremos el dominio de forma inversa
    /*for(x<- longitud-1 to 0 by -1){
      //Si es el primer valor por la derecha, introducimos un 1
      if(x == longitud-1){
        listaPesos = 1::listaPesos
        aux = 1
      }
      //Si es un valor diferente al primero, usamos la variable auxiliar y la multiplicamos por el valor anterior
      else{
        listaPesos = (aux * variables(x+1).estados) :: listaPesos
        aux = variables(x+1).estados
      }
    }*/
    //listaPesos
  }

  /**
    * Devuelve el máximo indice del dominio
    * @return
    */
  def maximoIndice:Int = {
    val listaPesos = pesos
    var acum = 0

    @annotation.tailrec
    def go(longitudActual:Int): Int ={
      if(longitudActual < longitud){
        acum += (variables(longitudActual).estados-1) * listaPesos(longitudActual)
        go(longitudActual+1)
      }else acum
    }
    go(0)
    //Metodo iterativo
    //for (x<-0 until longitud) acum+= (variables(x).estados-1) * listaPesos(x)
    //acum
  }
}

object Dominio{
  /**
    * Metodo que permite crear objetos de la clase Dominio
    * de forma sencilla
    * @param list
    * @return
    */
  def apply(list: List[Variable]): Dominio = new Dominio(list)


}