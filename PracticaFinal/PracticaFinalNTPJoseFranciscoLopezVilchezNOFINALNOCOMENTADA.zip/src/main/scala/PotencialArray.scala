class PotencialArray(dominio: Dominio, valoresArray: ValoresArray) extends Potencial(dominio,valoresArray) {


}

object PotencialArray{
  /**
    * Metodo que permite crear objetos de la clase PotencialArray con un Dominio y una lista de valores
    * @param dominio
    * @param valoresArray
    * @return
    */
  def apply(dominio: Dominio,valoresArray: ValoresArray): PotencialArray = new PotencialArray(dominio,valoresArray)
}
