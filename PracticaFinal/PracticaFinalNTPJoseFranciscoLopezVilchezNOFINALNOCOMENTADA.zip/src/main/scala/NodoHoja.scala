class NodoHoja(variable:Variable,valor:Int) extends Nodo {
  val nivel = variable
  val valorFinal = valor

  override def obtenerHijo(indice: Int): Int = {
    valorFinal
  }
  override def obtenerValor(asignacion: Asignacion): Int = ???
  override def obtenerValores: List[Int] = ???
}

object NodoHoja{
  def apply(variable: Variable, valor: Int): NodoHoja = new NodoHoja(variable, valor)
}
