abstract class Potencial(dominio: Dominio, valores: Valores) {
  val valor = valores
  override def toString: String = {
    var cadena = "Dominio del potencial: "
    cadena+=dominio
    cadena+="\nContenedor de valores: \n"
    cadena+=valores
    cadena
  }
  def obtenerValores: List[Int]=valores.obtenerValores
  def restringir(variable: Variable, estado:Int):Potencial={
    if(valores.isInstanceOf[ValoresArray]){
      val valoresRestringir = valores.asInstanceOf[ValoresArray].restringir(variable,estado)
      val potencialFinal = PotencialArray.apply(dominio,valoresRestringir)
      potencialFinal
    }else{
      ???
    }


  }
  def combinar(potencial:Potencial):Potencial={
    val combinacion = valor.combinar(potencial.valor)
    if(combinacion.isInstanceOf[ValoresArray]){
      PotencialArray(dominio,combinacion.asInstanceOf[ValoresArray])
    }else{
      PotencialArbol(dominio,combinacion.asInstanceOf[ValoresArbol])
    }
  }
  def convertir:Potencial={
    if(this.valores.isInstanceOf[ValoresArray]){
      PotencialArbol(dominio,this.valores.convertir(valores).asInstanceOf[ValoresArbol])
    }else{
      PotencialArray(dominio,this.valores.convertir(valores).asInstanceOf[ValoresArray])
    }
  }
}
